## linZenan第2章作业 测试脚本
- terminal 1:
    > $ roscore
- terminal 2:
    > $ rosrun turtlesim turtlesim_node
- terminal 3:(第1问)
    > $ rosrun learning_communication turtle_publisher_subscriber
- terminal 4:(第2问)
    > $ rosrun learning_communication turtle_client
- terminal 5:(第3问 --1 输入需要新建的乌龟名字)
    > $ rosrun learning_communication turtle_build

    > turtle3
- terminal 6:(第3问 --2 输入需要控制的乌龟和速度)
    > $ rosrun learning_communication turtle_contrel

    > turtle3

    > -0.2