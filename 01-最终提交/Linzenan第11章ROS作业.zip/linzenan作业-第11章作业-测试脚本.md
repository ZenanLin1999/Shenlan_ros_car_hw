## linZenan第11章作业 测试脚本
	- 课程中"迷宫寻宝"——exploring_slam_demo
        > $ roslaunch mbot_gazebo mbot_maze_gazebo.launch
	> $ roslaunch mbot_navigation exploring_slam_demo.launch
	> $ roslaunch mbot_vision find_target.launch

	- 课程中"迷宫寻宝"——nav_maze_demo
        > $ roslaunch mbot_gazebo mbot_maze_gazebo.launch
	> $ roslaunch mbot_navigation nav_maze_demo.launch
	> $ roslaunch mbot_vision find_target_pro.launch

	- 使用自己机器人的"迷宫寻宝"——exploring_slam_demo
        > $ roslaunch mbot_gazebo mbot_laser_nav_gazebo_homework.launch
	> $ roslaunch mbot_navigation exploring_slam_homework.launch
	> $ roslaunch mbot_vision find_target_homework.launch

	- 使用自己机器人的"迷宫寻宝"——nav_maze_demo
        > $ roslaunch mbot_gazebo mbot_laser_nav_gazebo_homework.launch
	> $ roslaunch mbot_navigation nav_homework.launch
	> $ roslaunch mbot_vision find_target_pro_homework.launch
