## linZenan第10章作业 测试脚本
	- 启动虚拟环境
        > $ roslaunch mbot_gazebo mbot_laser_nav_gazebo_homework.launch
	- 基于move_base和amcl自主导航仿真
	> $ roslaunch mbot_navigation nav_homework.launch
	- move_base+gmapping导航+slam
	> $ roslaunch mbot_navigation exploring_slam_homework.launch
	> $ rosrun mbot_navigation exploring_random_homework.py
