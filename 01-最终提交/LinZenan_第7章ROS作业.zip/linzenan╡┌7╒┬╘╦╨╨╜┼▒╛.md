## linZenan第7章作业 测试脚本
        - 通过左右摇头控制方向，前后控制前后。没有USB摄像头，只能使用笔记本自带的摄像头，第二问也是通过识别人的头像控制，可以通过修改"detect_ros_control_car.py"文件中的id和微调参数改变。
        - 问题1：
        > $ roslaunch robot_vision homework_face_detector_control.launch 
        > $ roslaunch mbot_gazebo view_homework_gazebo_empty_world.launch 
        - 问题2：
        > $ source ~/tensorflow_140_cp27/bin/activate       #激活虚拟环境，需要修改为虚拟环境具体位置
        > $ roslaunch tensorflow_object_detector  usb_cam_detector_control.launch
        > $ roslaunch mbot_gazebo view_homework_gazebo_empty_world.launch 