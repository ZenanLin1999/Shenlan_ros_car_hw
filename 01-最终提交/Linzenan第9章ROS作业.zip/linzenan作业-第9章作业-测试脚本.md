## linZenan第9章作业 测试脚本
	- 启动虚拟环境
        > $ roslaunch mbot_gazebo mbot_laser_nav_gazebo_homework.launch
	- gmapping建图方式
        > $ roslaunch mbot_navigation gmapping_demo.launch 
	> $ roslaunch mbot_teleop mbot_teleop.launch
	> $ rosrun map_server map_saver -f homework_gmapping
	- hector建图方式
	> $ roslaunch mbot_navigation hector_demo.launch
	> $ roslaunch mbot_teleop mbot_teleop.launch
	> $ rosrun map_server map_saver -f homework_hector
